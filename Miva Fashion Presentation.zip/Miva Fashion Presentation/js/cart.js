// Add to cart function
function addToCart(item) {
// Get the current cart from session storage
let cart = getSessionCart();

// Add the item to the cart
cart.push(item);

// Save the updated cart to session storage
sessionStorage.setItem("cart", JSON.stringify(cart));

console.log("Item added to cart:", item);
updateCartCount();
}

// Get cart from session storage
function getSessionCart() {
let cart = sessionStorage.getItem("cart");
return cart ? JSON.parse(cart) : [];
}

// Remove from cart function
function removeFromCart(id) {


  var iJsn = document.getElementById(id).innerHTML
  const item = JSON.parse(iJsn);
  console.log(item);

  let cart = getSessionCart();
  const index = cart.indexOf(1);

  console.log(index);

  if (index) {
    cart.splice(index, 1);
    sessionStorage.setItem("cart", JSON.stringify(cart));
    console.log("Item removed from cart:", item);
  }
  location.reload();
  display();
  updateCartCount();
}

// Update cart count function
function updateCartCount() {
const cartCount = getSessionCart().length;
document.getElementById("cartNo").innerHTML = cartCount;
}