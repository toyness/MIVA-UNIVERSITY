updateCartCount();

function display(){


    var cartList = document.getElementById('itemdisplay');

    for(i = 0; i < getSessionCart().length; i++){
        var li = document.createElement('li');
        var span = document.createElement('span');

        var arrDiv = '["'+getSessionCart()[i][0] +'","'+ getSessionCart()[i][1]+'"]';

        li.innerHTML = getSessionCart()[i][0] + getSessionCart()[i][1] + "<span class='rmItem' onclick='removeFromCart("+i+")'>&times</span>"+"<span id='"+i+"' hidden>"+arrDiv+"</span>";
        
        
        cartList.appendChild(li); 
    }
    
}